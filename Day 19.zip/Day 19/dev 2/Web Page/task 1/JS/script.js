function page1(){
  alert(' Do You want  to go back');
  history.back();
  
}